#include<pthread.h>
#ifndef LIBAES
#define LIBAES
extern size_t FILE_SIZE;
extern long int BLOCKS;
extern unsigned char S_BOX[256];
extern unsigned char RS_BOX[256];
extern pthread_mutex_t lock;
extern char *FILENAME,*E_FILENAME,*D_FILENAME;
extern unsigned char Key[16];
// DataStructures
struct DataBlock {
	unsigned char Byte[4][4];};
struct KeyBlock {
	unsigned char Byte[4][4];};
struct KeyShedule {
	unsigned char Byte[11][4][4];
	};
// Extra
extern int getsize(char * stream);
extern void getword(unsigned char *dest,struct KeyShedule *KS,int Round,int Word);
extern void setword(unsigned char *dest,struct KeyShedule *KS,int Round,int Word);
extern void lrot(unsigned char *Word);
extern void wxor(unsigned char *m,unsigned char *p);
// DataBlock Functions
extern void SetBlock(struct DataBlock * DB,unsigned char C[16]);
extern void ShowHex(struct DataBlock DB);
extern void ShowRaw(struct DataBlock DB);
extern void xShowHex(struct DataBlock * DB);
// KeyBlock and Schedule
extern void SetKey(struct KeyShedule * KS,unsigned char C[16]);
extern void KeyHex(struct KeyShedule KS,int Round);
extern void KeyRaw(struct KeyBlock KB);
extern void xKeyHex(struct KeyShedule *KS,int Round);
// Encryption Functions
extern unsigned char gmul(unsigned char a,unsigned char b);
extern void Sub_Byte(struct DataBlock *DB);
extern void Inv_Sub_Byte(struct DataBlock *DB);
extern void Shift_Row(struct DataBlock *DB);
extern void Inv_Shift_Row(struct DataBlock *DB);
extern void Mix_Column(struct DataBlock *DB);
extern void Inv_Mix_Column(struct DataBlock *DB);
extern void Add_Round_Key(struct DataBlock *DB, struct KeyShedule *KS,int Round);
extern void Inv_Add_Round_Key(struct DataBlock *DB, struct KeyShedule *KS,int Round);
// AES Higher functions
extern void aes_encrypt(struct DataBlock *DB,struct KeyShedule *KS);
extern void aes_decrypt(struct DataBlock *DB,struct KeyShedule *KS);
extern struct KeyShedule KS;
extern size_t getfs(char *filename);
#define NUM_OF_ENG 10
extern char ENGINE_STAT[NUM_OF_ENG];
extern long int C_CYCLE,C_BLOCK;
extern char ENGINE_STAT[NUM_OF_ENG];
extern int STOP;
extern void * STAT();
extern void * encrypt_block(void * block_id);
void Encrypt_file(char * filename,char * outputfilename);
extern void * decrypt_block(void * block_id);
extern void Decrypt_file(char * filename,char * outputfilename);
#endif
