cd lib
bash make.sh
cd ..
gcc -Wall -o aes_machine main.c lib/libaes.o lib/keyman.o lib/argman.o -lpthread
gcc -Wall -o keygen keygen.c lib/keyman.o lib/argman.o