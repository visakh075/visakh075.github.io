put your library source files 
here eg: libXXX.cpp libXXX.h
output files will be generated at obj/
