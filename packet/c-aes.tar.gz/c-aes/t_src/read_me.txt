put your test codes here
outputs will be generated at t_bin/
