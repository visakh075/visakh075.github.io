#include<stdio.h>
#include "keyman.h"
#include "argman.h"
unsigned char gKey[16];
int main(int argc,char * argv[])
{
    arg_map map;
    char arglist[]="gr";
    int exp[]={0,0};
    int conf[]={0,0};
    int def[]={0,1};
    map_init(&map,arglist,exp,conf,def,1,argc,argv);
    if(!error(map))
    {
        if(safe('g',map))
        {
            GenarateKey(branch('.',map)->param[0]);
        }
        if(safe('r',map))
        {
            GetKey(branch('.',map)->param[0]);
            for(int i=0;i<16;i++)
            {
                printf("%02x ",gKey[i]);
            }
            printf("\b\n");
        }
    }
    return(0);
}