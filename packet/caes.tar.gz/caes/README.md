# c-aes
aes implimentation

target filename : aes_machine
arguments

    method [
        e - enc (default)
        d - dec
    ]
    replace [
        r - rewrites the file (default)
        n - create new file [new filename]
    ]
    keyman[
        k - [key filename] for key
        if not use GetKey()
    ]

        e   d   n   r   k
    e   1   1   0   0   0
    d   1   1   0   0   0
    n   0   0   1   1   0
    r   0   0   1   1   0
    k   0   0   0   0   1

    recursive conflict map to lowest conflict opt
    conflict groups
    or  0   1   2   3   4
        e   d   n   r   k
        0   0   1   1   -1

    error flag
    -1 none
    0  exist none
    1 missing para
    2 conflict error

    pos with respect to argc
    