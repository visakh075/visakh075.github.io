#include<stdio.h>
#include "lib/libaes.h"
#include "lib/keyman.h"
#include "lib/argman.h"
int main(int argc,char *argv[]){

	arg_map map;
    char op[]="ednrk";
    int exp[]={0,0,1,0,1};
    int conf[]={0,0,1,1,-1};
    int def[]={1,0,0,1,0};
    char * input="";
    char * output="";
    char * key="";
	int enc=1;
	map_init(&map,op,exp,conf,def,1,argc,argv);
	if(!error(map)) // no error
	{
		if(safe('e',map))
		{
			enc=1;	// encrypt
		}
		if(safe('d',map))
		{
			enc=0;	// decrypt
 		}
		if(safe('n',map)) 
        {
            output=branch('n',map)->param[0];
        }
		if(safe('k',map))
        {
            key=branch('k',map)->param[0];
			GetKey(key);
        }
		else
		{
			GetKey("KEY");
		}
		
		input=branch('.',map)->param[0];

		if(enc==0)
		{
			Decrypt_file(input,output);
		}
		else
		{
			Encrypt_file(input,output);
		}
	}
	else
	{
		printf("error\n");
	}
	return(0);
}