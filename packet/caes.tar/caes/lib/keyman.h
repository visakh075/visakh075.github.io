#ifndef KEYMAN
#define KEYMAN
void GetKey(char * keyfile);
void GenarateKey(char * keyfile);
#endif