gcc -o argman.o -c argman.c
gcc -Wall -o hexcomp -c hexcomp.c
gcc -o keyman.o -c keyman.c
gcc -o libaes.o -c libaes.c